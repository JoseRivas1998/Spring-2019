/**
* Name: Jose de Jesus Rodriguez Rivas
* Lab: Lab 4
* Date: 02/20/19
**/

#include "scanner.h"

#ifndef SCANNER1_SCANNERNESTEDCASES_H
#define SCANNER1_SCANNERNESTEDCASES_H
TOKEN *scannerNestedCases();
void copyIntoStringValue(TOKEN *token, char *strToCpy);
#endif //SCANNER1_SCANNERNESTEDCASES_H
